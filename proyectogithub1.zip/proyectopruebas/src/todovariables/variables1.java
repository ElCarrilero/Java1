package todovariables;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class variables1 {
	
	public static String varClase = "Variable clase";
	
	public void ejemplovariablesprimitivas() {
	
	final byte edad;//Definición variable primera manera. -2 elevado a 7 a +2 elevado a 7 -1.
	edad = 12;
	short varShort = -300;//Definición variable segunda manera. -2 elevado a 15 a +2 elevado a 15 - 1.
	int varInt = 2147483647; //-2 elevado a 31 a +2 elevado a 31 - 1.
	long varLong = 2147483650L; //-2 elevado a 63 +2 elevado a 63 - 1.
	float varFloat = 37.56F; //numeros decimales precisión simple.
	double varDouble = 56.234543635; //numeros decimales precisión doble.
	boolean varBoolean = true; //Valor verdadero o falso.
	char varChar = 'c'; //conjunto de carácteres que forman parte del lenguaje humano.
	
	//Constante se añade la palabra final al principio de la variable y pasa a ser una constante.
	final byte peso = 74;
	
	
	
	System.out.println("clarita pesa: "+edad);
	System.out.println("varShort: " +varShort);
	System.out.println("varInt: "+varInt);
	System.out.println("varLong: "+varLong);
	System.out.println("varFloat: "+varFloat);
	System.out.println("varDouble: "+varDouble);
	System.out.println("varBoolean: "+varBoolean);
	System.out.println("varChar: "+varChar);
	System.out.println("tu peso es: "+peso);
	
	

}
	public void ejemplovariablesobjeto() {
		//CADENA DE TEXTO
		String apellido = ("DEL PINO");//Si mediante el codigo queremos cambiar el valor pondria apellido = "perez"; 
		//vale para esta y todas las variables anteriores 
		
			
		//ARRAY 
		//es un conjunto de cadenas de texto.
		String[] nombrehermanos = {"alfonso","amira","alejandra"};
		
		
		//LISTAS
		List<String> listacompra = new ArrayList<String>();
		listacompra.add("leche");
		listacompra.add("harina");
		listacompra.add("azucar");
		
		//Ejemplo objeto televisión
		
		//Televesion varTelevision = new Television("LG,55");
				
		
		
		
		
		
		
		
		
		System.out.println("apellido: " +apellido);
		System.out.println("nombre hermanos: "+Arrays.toString(nombrehermanos));
		System.out.println("lista De la compra: "+Arrays.toString(listacompra.toArray()));
		//System.out.println("la television es: "+varTelevision);
		
	}
	}
