package todovariables;

public class runvariables {

	public static void main(String[] args) {
		
		variables1 ejvariables1 = new variables1();
		ejvariables1.ejemplovariablesprimitivas();
		ejvariables1.ejemplovariablesobjeto();
		//System.out.println("variable de clase = "+variables1.varClase);
		

		

	}

}
