package pakegemetodos;

import javax.swing.JOptionPane;

public class metodos1 {
//ATRIBUTOS
	int numero1;
	int numero2;
	int resta;
	int suma;
	int multiplicacion;
	int division;
	
	//METODOS
	
	//Método para pedirle al usuario que nos digite dos numeros.
	
	public void leernumeros() {
		
		numero1 = Integer.parseInt(JOptionPane.showInputDialog("Digite un numero: "));
		numero2 = Integer.parseInt(JOptionPane.showInputDialog("Digite un numero: "));
	}
//Metodo para sumar numeros
	public void sumar() {
		suma = numero1+numero2;
	}
//Metodo para resta numeros
	public void restar() {
		resta = numero1-numero2;
	}
//Metodo para multiplicar numeros
	public void multiplicar( ) {
		multiplicacion = numero1*numero2;
	}
//Metodo para dividir numeros
	public void dividir( ) {
		division = numero1/numero2;
	}

	public void mostrarResultados() {
		System.out.println("la suma es: "+suma);
		System.out.println("la resta es: "+resta);
		System.out.println("la multiplicacion es: "+multiplicacion);
		System.out.println("la division es: "+division);
	}
	

}





