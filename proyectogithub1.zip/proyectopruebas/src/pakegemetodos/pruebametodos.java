package pakegemetodos;



public class pruebametodos {

	public static void main(String[] args) {
		
		metodos1 op = new metodos1();
		
		op.leernumeros();
		op.restar();
		op.sumar();
		op.multiplicar();
		op.dividir();
		op.mostrarResultados();
		
	}

}
