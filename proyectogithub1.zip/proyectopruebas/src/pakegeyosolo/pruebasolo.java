package pakegeyosolo;

import javax.swing.JOptionPane;

public class pruebasolo {

	int numeroUno;
	int numeroDos;
	int suma1;
	int resta1;
	int division1;
	int multiplicacion1;
	
	public void leernumeros1 (){
	
	numeroUno = Integer.parseInt(JOptionPane.showInputDialog("Digite un numero: "));
	numeroDos = Integer.parseInt(JOptionPane.showInputDialog("Digite otro numero: "));
	
	}	

    public void sumar1 () {
    	
    	suma1 = numeroUno + numeroDos;
    	}
    public void restar1() {
		
    	resta1 = numeroUno - numeroDos;
	}
    public void dividir1() {
		
    	division1 = numeroUno / numeroDos;
	}

    public void multiplicar1() {
		
    	multiplicacion1 = numeroUno * numeroDos;
	}
    
    public void mostrarResultados1() {
    	
    	System.out.println("la suma es: "+suma1);
    	System.out.println("la resta es: "+resta1);
    	System.out.println("la division es: "+division1);
    	System.out.println("la multiplicacion es: "+multiplicacion1);
		
	}
}



