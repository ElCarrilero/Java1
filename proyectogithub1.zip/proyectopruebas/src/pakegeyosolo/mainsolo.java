package pakegeyosolo;

public class mainsolo {

	public static void main(String[] args) {
		pruebasolo ps = new pruebasolo();
		ps.leernumeros1();
ps.sumar1();
ps.restar1();
ps.dividir1();
ps.multiplicar1();
ps.mostrarResultados1();
	}

}
