package metodoscurso;

public class mainmetodoscurso {

	public static void main(String[] args) {
		pruebametotos pm = new pruebametotos();
		pm.calcularMultiplicacion();

	}

}
