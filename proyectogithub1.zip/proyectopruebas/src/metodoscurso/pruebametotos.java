package metodoscurso;

import java.lang.reflect.AccessibleObject;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class pruebametotos {

	
	public float calcularMultiplicacion() {
		//VARIABLES LOCALES, estan dentro de algun metodo y solo se pueden usar dentro de este.
		float multiplicando, multiplicador, producto = 0;
		//Instancio clase para leer por consola.
		Scanner sc = new Scanner(System.in);
		//leo datos
		System.out.println("DIGITE UN NUMERO: ");
		multiplicando = sc.nextFloat();
		System.out.println("DIGITE OTRO NUMERO: ");
		multiplicador = sc.nextFloat();
		
		//Realizamos la multiplicacion
		producto = multiplicando * multiplicador;
		System.out.println("EL RESULTADO ES: "+producto);
		return producto;
		
		
	}
	}
